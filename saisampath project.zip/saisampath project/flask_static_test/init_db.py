import sqlite3

conn = sqlite3.connect('moviemagic.db')
c = conn.cursor()

# Create a fresh payments table
c.execute('''
    CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        payment_method TEXT,
        account_number TEXT,
        cardholder TEXT,
        expiry TEXT,
        cvv TEXT
    )
''')

conn.commit()
conn.close()

print("✅ Database and payments table created successfully!")
